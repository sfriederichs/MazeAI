#ifndef __D_DRAWER__
#define __D_DRAWER__

void D_DrawMap( void );
void D_DrawHUD( int i );
void D_TextBuffer( int length );

char text[LINES][50];

#endif
