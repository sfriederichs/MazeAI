#ifndef __G_GAME__
#define __G_GAME__

int G_GameLoop( void );
void G_WriteTimes(void);
int gamecount;

#endif
