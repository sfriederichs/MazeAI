#include <stdio.h>
#include "main.h"
#include <string.h>

int main()
{
 S_InitCommands();

 S_LoadScript();

 I_Debug( script[0].name );
 I_Debug( script[1].name );
 I_Debug( script[2].name );

 I_Debug( script[0].raw[0] );
 I_Debug( script[0].raw[1] );
 I_Debug( script[1].raw[0] );
 I_Debug( script[2].raw[0] );

 I_IntDebug( script[0].loc.x );
 I_IntDebug( script[0].loc.y );


 return 1;
}

void I_Debug( char * message )
{
 FILE *crap = fopen("script.dbg", "at+");
 fprintf(crap, "%s\n",message);
 fclose(crap);
}

void I_IntDebug( int num )
{
 FILE *crap = fopen("script.dbg", "at+");
 fprintf(crap, "%d\n", num);
 fclose(crap);
}

void S_InitCommands( void )
{

 sprintf(commands[0].name, "BotLoc =");
 commands[0].inputype = 2;

 sprintf(commands[1].name, "GoalLoc =");
 commands[1].inputype = 2;

}

void S_LoadScript( void )
{
 FILE *bah = fopen("ai.dem", "rt+");
 int p,i = -1,linenum, scriptnum;
 char file[80][80],c;

 do
 {
 
  c = fgetc(bah);

  i++; //Chracter counter

  for(p=0;p<2;p++) //At end of line check for command
  { 
   if(strcmp(file[linenum], commands[p].name) == 0) //Are they the same?
   {

    sprintf(script[scriptnum].name, file[linenum]); //Copy the command found in the file to the parsed data

    linenum++;
    i = 0;

    S_LoadValues(script[scriptnum]);

    S_AssignValues(script[scriptnum]);

    scriptnum++;
    linenum++;

    }
   }

   if (c == '\n') //End of line check //Note, this is needed
    i = -1;    //Clear all
   else
    file[linenum][i] = c; //If the line isn't finished, and it's not a newline, add it to the raw

  }while(!feof(bah));

 fclose(bah);
}

void S_LoadValues( scriptcmd_t *command )
{
 FILE *bah = fopen("ai.dem", "rt+" );
 char c;
 int i = -1;

 do
 {
  i++;

  c = fgetc(bah);

  if(c == ',')
  {
   *command.counter++;
   continue;
  }      

  if(c == '\n' )
   break;

  *command.raw[*command.counter][i] = c; //Add the current character (while not a \n or a ,) to the raw value

 }while(c != '\n'); //I really don't need that while, but it's required
}


void S_AssignValues( scriptcmd_t *command )
{

 int i;

 for(i = 0; i<COMMANDS;i++)
 {
  if(strcmp(command.name, commands[i].name) == 0)
  { 
   switch(commands[i].inputype)
   {

    case 1: //Simple Value
     command.value = atoi(command.raw[0]);
     break;

    case 2: //A loc
     command.loc.x = atoi(command.raw[0]);
     command.loc.y = atoi(command.raw[1]);
     break;

    case 3: //AI Traits
     command.ai.thriftyness = atoi(command.raw[0]);
     command.ai.updown = atoi(command.raw[1]);
     command.ai.annoyance = atoi(command.raw[2]);
     command.ai.resolutness = atoi(command.raw[3]);
     command.ai.lookahead = atoi(command.raw[4]);
     break;      
           
    case 4:
     for(i=0;i<LINES;i++)
      strcpy(command.text[i], command.raw[i]);
     break;
   }       
  }
 }
} 